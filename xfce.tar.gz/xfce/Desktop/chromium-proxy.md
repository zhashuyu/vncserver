### chromium配合jmeter配置代理命令行
```
/usr/bin/chromium %U --no-sandbox --disable-gpu --maximum --proxy-server="socks://localhost:8080"
```
